package co.edu.unicauca.identity.api.controller;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;

import co.edu.unicauca.identity.api.dto.LoginRequest;
import co.edu.unicauca.identity.api.dto.UserResponse;
import co.edu.unicauca.identity.application.IdentityService;

@RestController
@RequestMapping("/api/auth")
public class AuthController {

    private final IdentityService identityService;

    public AuthController(IdentityService identityService) {
        this.identityService = identityService;
    }

    @PostMapping("/login")
    public ResponseEntity<UserResponse> login(
            @Valid @RequestBody LoginRequest request) {

        return ResponseEntity.ok(
                UserResponse.fromDomain(
                        identityService.authenticate(
                                request.getEmail(),
                                request.getPassword()
                        )
                )
        );
    }
}
