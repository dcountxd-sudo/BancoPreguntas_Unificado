package co.edu.unicauca.identity.domain.model;

/**
 * Roles available in the question bank.
 */
public enum Role {

    AUTHOR,
    REVIEWER,
    ADMIN
}
