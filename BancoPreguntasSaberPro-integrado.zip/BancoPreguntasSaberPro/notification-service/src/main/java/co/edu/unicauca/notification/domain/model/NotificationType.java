package co.edu.unicauca.notification.domain.model;

/**
 * Kinds of notification produced by the question bank.
 */
public enum NotificationType {

    REVIEW_ASSIGNED,
    REVIEW_APPROVED,
    REVIEW_REJECTED
}
