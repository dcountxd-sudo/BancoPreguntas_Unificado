package co.edu.unicauca.notification.config;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.http.client.SimpleClientHttpRequestFactory;
import org.springframework.web.client.RestClient;

import co.edu.unicauca.notification.application.client.IdentityGateway;
import co.edu.unicauca.notification.infrastructure.client.IdentityServiceClient;

/**
 * Configures the REST client used to reach the Identity Service.
 */
@Configuration
public class IdentityClientConfig {

    @Bean
    public IdentityGateway identityGateway(
            @Value("${identity.service.url}") String identityUrl) {

        SimpleClientHttpRequestFactory requestFactory =
                new SimpleClientHttpRequestFactory();
        requestFactory.setConnectTimeout(3000);
        requestFactory.setReadTimeout(3000);

        return new IdentityServiceClient(
                RestClient.builder()
                        .baseUrl(identityUrl)
                        .requestFactory(requestFactory)
                        .build()
        );
    }
}
