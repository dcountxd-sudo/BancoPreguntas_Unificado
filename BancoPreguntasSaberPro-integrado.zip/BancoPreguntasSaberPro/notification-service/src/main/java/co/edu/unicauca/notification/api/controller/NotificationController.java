package co.edu.unicauca.notification.api.controller;

import java.util.List;

import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PatchMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import co.edu.unicauca.notification.api.dto.NotificationResponse;
import co.edu.unicauca.notification.application.NotificationService;

@RestController
@RequestMapping("/api/notifications")
public class NotificationController {

    private final NotificationService notificationService;

    public NotificationController(NotificationService notificationService) {
        this.notificationService = notificationService;
    }

    @GetMapping
    public ResponseEntity<List<NotificationResponse>> findByRecipient(
            @RequestParam Long recipientId) {

        return ResponseEntity.ok(
                notificationService.findByRecipient(recipientId).stream()
                        .map(NotificationResponse::fromDomain)
                        .toList()
        );
    }

    @PatchMapping("/{id}/read")
    public ResponseEntity<NotificationResponse> markAsRead(
            @PathVariable Long id) {

        return ResponseEntity.ok(
                NotificationResponse.fromDomain(
                        notificationService.markAsRead(id)
                )
        );
    }
}
