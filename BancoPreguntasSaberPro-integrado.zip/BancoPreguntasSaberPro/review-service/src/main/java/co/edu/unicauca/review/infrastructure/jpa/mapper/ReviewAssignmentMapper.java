package co.edu.unicauca.review.infrastructure.jpa.mapper;

import org.springframework.stereotype.Component;

import co.edu.unicauca.review.domain.model.Review;
import co.edu.unicauca.review.domain.model.ReviewAssignment;
import co.edu.unicauca.review.infrastructure.jpa.record.ReviewAssignmentRecord;
import co.edu.unicauca.review.infrastructure.jpa.record.ReviewRecord;

@Component
public class ReviewAssignmentMapper {

    public ReviewAssignmentRecord toRecord(ReviewAssignment assignment) {

        ReviewAssignmentRecord record = new ReviewAssignmentRecord();

        record.setQuestionId(assignment.getQuestionId());
        record.setAuthorId(assignment.getAuthorId());

        for (Review review : assignment.getReviews()) {
            ReviewRecord reviewRecord = toReviewRecord(review);
            record.addReview(reviewRecord);
        }

        return record;
    }

    public ReviewAssignmentRecord updateRecord(
            ReviewAssignment assignment,
            ReviewAssignmentRecord record) {

        record.setQuestionId(assignment.getQuestionId());
        record.setAuthorId(assignment.getAuthorId());

        // A new review round removes the reviews of the previous one.
        record.getReviews().removeIf(existing ->
                assignment.getReviews().stream().noneMatch(review ->
                        review.getReviewerId().equals(
                                existing.getReviewerId())));

        for (Review review : assignment.getReviews()) {

            ReviewRecord existingReview = record.getReviews()
                    .stream()
                    .filter(existing ->
                            existing.getReviewerId().equals(
                                    review.getReviewerId()
                            ))
                    .findFirst()
                    .orElse(null);

            if (existingReview == null) {

                record.addReview(toReviewRecord(review));

            } else {

                existingReview.setQuestionId(review.getQuestionId());
                existingReview.setReviewerId(review.getReviewerId());
                existingReview.setStatus(review.getStatus());
                existingReview.setObservations(review.getObservations());
                existingReview.setReviewedAt(review.getReviewedAt());
            }
        }

        return record;
    }


    private ReviewRecord toReviewRecord(Review review) {

        ReviewRecord record = new ReviewRecord();

        record.setQuestionId(review.getQuestionId());
        record.setReviewerId(review.getReviewerId());
        record.setStatus(review.getStatus());
        record.setObservations(review.getObservations());
        record.setReviewedAt(review.getReviewedAt());

        return record;
    }

    public ReviewAssignment toDomain(ReviewAssignmentRecord record) {

        ReviewAssignment assignment = ReviewAssignment.restore(
            record.getId(),
            record.getQuestionId(),
            record.getAuthorId()
        );

        for (ReviewRecord reviewRecord : record.getReviews()) {
            Review review = toReviewDomain(reviewRecord);
            assignment.restoreReview(review);
        }

        return assignment;
    }

    private Review toReviewDomain(ReviewRecord record) {

        return Review.restore(
                record.getQuestionId(),
                record.getReviewerId(),
                record.getStatus(),
                record.getObservations(),
                record.getReviewedAt()
        );
    }
}