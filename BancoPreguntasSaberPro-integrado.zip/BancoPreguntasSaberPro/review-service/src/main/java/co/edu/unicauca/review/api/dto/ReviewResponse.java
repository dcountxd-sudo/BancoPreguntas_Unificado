package co.edu.unicauca.review.api.dto;

import java.time.LocalDateTime;

import co.edu.unicauca.review.domain.model.Review;
import co.edu.unicauca.review.domain.model.ReviewStatus;

public class ReviewResponse {

    private Long reviewerId;
    private ReviewStatus status;
    private String observations;
    private LocalDateTime reviewedAt;

    public ReviewResponse(
            Long reviewerId,
            ReviewStatus status,
            String observations,
            LocalDateTime reviewedAt) {

        this.reviewerId = reviewerId;
        this.status = status;
        this.observations = observations;
        this.reviewedAt = reviewedAt;
    }

    public static ReviewResponse fromDomain(Review review) {
        return new ReviewResponse(
                review.getReviewerId(),
                review.getStatus(),
                review.getObservations(),
                review.getReviewedAt()
        );
    }

    public Long getReviewerId() {
        return reviewerId;
    }

    public ReviewStatus getStatus() {
        return status;
    }

    public String getObservations() {
        return observations;
    }

    public LocalDateTime getReviewedAt() {
        return reviewedAt;
    }
}