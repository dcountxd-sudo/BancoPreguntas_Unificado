package co.edu.unicauca.review.api.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;

import co.edu.unicauca.review.api.dto.AssignReviewersRequest;
import co.edu.unicauca.review.api.dto.ReviewAssignmentResponse;
import co.edu.unicauca.review.api.dto.ReviewDecisionRequest;
import co.edu.unicauca.review.application.ReviewApplicationService;
import co.edu.unicauca.review.domain.model.ReviewAssignment;

@RestController
@RequestMapping("/api/reviews")
public class ReviewController {

    private final ReviewApplicationService service;

    public ReviewController(ReviewApplicationService service) {
        this.service = service;
    }

    @PostMapping("/assign")
    public ResponseEntity<ReviewAssignmentResponse> assignReviewers(
            @Valid @RequestBody AssignReviewersRequest request) {

        ReviewAssignment assignment = service.assignReviewers(
                request.getQuestionId(),
                request.getAuthorId(),
                request.getReviewerIds()
        );

        return ResponseEntity
                .status(HttpStatus.CREATED)
                .body(ReviewAssignmentResponse.fromDomain(assignment));
    }

    @PostMapping("/{questionId}/decision")
    public ResponseEntity<ReviewAssignmentResponse> registerDecision(
            @PathVariable Long questionId,
            @Valid @RequestBody ReviewDecisionRequest request) {

        ReviewAssignment assignment;

        if (request.getApproved()) {
            assignment = service.approveReview(
                    questionId,
                    request.getReviewerId()
            );
        } else {
            assignment = service.rejectReview(
                    questionId,
                    request.getReviewerId(),
                    request.getObservations()
            );
        }

        return ResponseEntity.ok(
                ReviewAssignmentResponse.fromDomain(assignment)
        );
    }

    @GetMapping("/pending")
    public ResponseEntity<List<ReviewAssignmentResponse>>
            getPendingAssignments() {

        return ResponseEntity.ok(
                service.findPendingAssignments().stream()
                        .map(ReviewAssignmentResponse::fromDomain)
                        .toList()
        );
    }

    @GetMapping("/reviewer/{reviewerId}")
    public ResponseEntity<List<ReviewAssignmentResponse>>
            getAssignmentsByReviewer(@PathVariable Long reviewerId) {

        return ResponseEntity.ok(
                service.findAssignmentsByReviewer(reviewerId).stream()
                        .map(ReviewAssignmentResponse::fromDomain)
                        .toList()
        );
    }

    @GetMapping("/{questionId}")
    public ResponseEntity<ReviewAssignmentResponse> getAssignment(
            @PathVariable Long questionId) {

        ReviewAssignment assignment =
                service.getAssignment(questionId);

        return ResponseEntity.ok(
                ReviewAssignmentResponse.fromDomain(assignment)
        );
    }
}