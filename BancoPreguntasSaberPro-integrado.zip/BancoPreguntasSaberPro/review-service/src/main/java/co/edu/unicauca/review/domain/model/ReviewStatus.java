package co.edu.unicauca.review.domain.model;

/**
 * Represents the status of an individual review.
 */
public enum ReviewStatus {

    PENDING,
    APPROVED,
    REJECTED
}
