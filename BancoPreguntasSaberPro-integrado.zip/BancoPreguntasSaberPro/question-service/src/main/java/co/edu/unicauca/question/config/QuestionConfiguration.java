
package co.edu.unicauca.question.config;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import co.edu.unicauca.question.domain.builder.QuestionDirector;
import co.edu.unicauca.question.domain.builder.QuestionBuilder;
import co.edu.unicauca.question.domain.builder.SingleChoiceQuestionBuilder;
import co.edu.unicauca.question.domain.validation.SingleChoiceQuestionValidator;

@Configuration
public class QuestionConfiguration {

    @Bean
    public SingleChoiceQuestionValidator singleChoiceQuestionValidator() {
        return new SingleChoiceQuestionValidator();
    }

    @Bean
    public QuestionBuilder questionBuilder() {
        return new SingleChoiceQuestionBuilder();
    }

    @Bean
    public QuestionDirector questionDirector(QuestionBuilder builder) {
        return new QuestionDirector(builder);
    }
}
