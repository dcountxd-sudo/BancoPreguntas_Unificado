package co.edu.unicauca.question.domain.builder;

import co.edu.unicauca.question.domain.model.Question;
import co.edu.unicauca.question.domain.model.QuestionOption;

import java.util.List;
/**
 * Directs the construction of a question.
 */
public class QuestionDirector {

    private final QuestionBuilder builder;

    public QuestionDirector(QuestionBuilder builder) {
        if (builder == null) {
            throw new IllegalArgumentException(
                    "Question builder cannot be null"
            );
        }

        this.builder = builder;
    }

    public Question constructQuestion(
            Long authorId,
            String statement,
            String context,
            String difficulty,
            String category,
            String topic,
            String subtopic,
            String competence,
            String justification,
            String source,
            List<QuestionOption> options) {

        builder.buildAuthor(authorId);
        builder.buildStatement(statement);
        builder.buildContext(context);
        builder.buildDifficulty(difficulty);
        builder.buildCategory(category);
        builder.buildTopic(topic);
        builder.buildSubtopic(subtopic);
        builder.buildCompetence(competence);
        builder.buildJustification(justification);
        builder.buildSource(source);

        if (options == null) {
            throw new IllegalArgumentException("Question options cannot be null");
         }
        for (QuestionOption option : options) {
            builder.addOption(option.getText(), option.isCorrect());
        }

        builder.buildOptions();

        return builder.build();
    }
}