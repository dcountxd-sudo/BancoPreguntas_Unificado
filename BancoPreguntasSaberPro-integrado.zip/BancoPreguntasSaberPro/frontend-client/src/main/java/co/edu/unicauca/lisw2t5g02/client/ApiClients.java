package co.edu.unicauca.lisw2t5g02.client;

import co.edu.unicauca.lisw2t5g02.config.ServiceUrls;

/** Groups the clients of the four microservices. */
public record ApiClients(
        IdentityClient identity,
        QuestionClient question,
        ReviewClient review,
        NotificationClient notification) {

    public static ApiClients create(ServiceUrls urls) {
        RestClient http = new RestClient();

        return new ApiClients(
                new IdentityClient(http, urls.identity()),
                new QuestionClient(http, urls.question()),
                new ReviewClient(http, urls.review()),
                new NotificationClient(http, urls.notification()));
    }
}
