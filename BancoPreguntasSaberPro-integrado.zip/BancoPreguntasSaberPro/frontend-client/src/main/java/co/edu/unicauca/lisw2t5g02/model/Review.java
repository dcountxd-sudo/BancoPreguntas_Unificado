package co.edu.unicauca.lisw2t5g02.model;

/** Evaluation left by one reviewer. */
public record Review(
        long reviewerId,
        ReviewStatus status,
        String observations,
        String reviewedAt) {
}
