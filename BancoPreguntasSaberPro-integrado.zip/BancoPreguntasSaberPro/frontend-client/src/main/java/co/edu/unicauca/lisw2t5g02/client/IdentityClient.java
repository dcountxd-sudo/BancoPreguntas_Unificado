package co.edu.unicauca.lisw2t5g02.client;

import java.util.List;

import com.fasterxml.jackson.databind.node.ObjectNode;

import co.edu.unicauca.lisw2t5g02.model.Role;
import co.edu.unicauca.lisw2t5g02.model.User;

/** REST client of the Identity Service. */
public class IdentityClient {

    private final RestClient http;
    private final String baseUrl;

    public IdentityClient(RestClient http, String baseUrl) {
        this.http = http;
        this.baseUrl = baseUrl;
    }

    public User login(String email, String password) {

        ObjectNode body = http.mapper().createObjectNode();
        body.put("email", email);
        body.put("password", password);

        return Mappers.toUser(http.post(baseUrl + "/api/auth/login", body));
    }

    public List<User> findUsers(Role role) {
        String query = role == null ? "" : "?role=" + role.name();
        return Mappers.toUsers(http.get(baseUrl + "/api/users" + query));
    }

    public User findById(long id) {
        return Mappers.toUser(http.get(baseUrl + "/api/users/" + id));
    }
}
