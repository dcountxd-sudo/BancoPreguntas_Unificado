package co.edu.unicauca.lisw2t5g02.model;

import java.util.List;
import java.util.Optional;

/** Reviewers assigned to a question, with their evaluations. */
public record ReviewAssignment(
        long id,
        long questionId,
        long authorId,
        List<Review> reviews,
        ReviewStatus consolidatedStatus) {

    /** Finds the review of one reviewer, if the reviewer is assigned. */
    public Optional<Review> reviewOf(long reviewerId) {
        return reviews.stream()
                .filter(review -> review.reviewerId() == reviewerId)
                .findFirst();
    }
}
