package co.edu.unicauca.lisw2t5g02.model;

/** One answer option of a question. */
public record QuestionOption(String text, boolean correct) {
}
