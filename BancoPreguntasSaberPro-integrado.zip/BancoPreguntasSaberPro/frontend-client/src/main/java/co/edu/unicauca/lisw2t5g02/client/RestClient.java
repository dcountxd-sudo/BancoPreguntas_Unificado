package co.edu.unicauca.lisw2t5g02.client;

import java.io.IOException;
import java.net.URI;
import java.net.http.HttpClient;
import java.net.http.HttpRequest;
import java.net.http.HttpResponse;
import java.time.Duration;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import com.fasterxml.jackson.databind.node.MissingNode;

/**
 * Minimal JSON-over-HTTP client shared by all service clients.
 * Services answer errors with plain text, which becomes the exception message.
 */
public class RestClient {

    private static final Duration TIMEOUT = Duration.ofSeconds(10);

    private final HttpClient httpClient = HttpClient.newBuilder()
            .connectTimeout(Duration.ofSeconds(3))
            .build();

    private final ObjectMapper mapper = new ObjectMapper();

    public JsonNode get(String url) {
        return send(request(url).GET().build(), url);
    }

    public JsonNode post(String url, Object body) {
        HttpRequest.BodyPublisher publisher = body == null
                ? HttpRequest.BodyPublishers.noBody()
                : json(body);

        return send(request(url).POST(publisher).build(), url);
    }

    public JsonNode put(String url, Object body) {
        return send(request(url).PUT(json(body)).build(), url);
    }

    public JsonNode patch(String url) {
        return send(request(url)
                .method("PATCH", HttpRequest.BodyPublishers.noBody())
                .build(), url);
    }

    public ObjectMapper mapper() {
        return mapper;
    }

    private HttpRequest.Builder request(String url) {
        return HttpRequest.newBuilder(URI.create(url))
                .timeout(TIMEOUT)
                .header("Accept", "application/json")
                .header("Content-Type", "application/json");
    }

    private HttpRequest.BodyPublisher json(Object body) {
        try {
            return HttpRequest.BodyPublishers.ofString(
                    mapper.writeValueAsString(body));
        } catch (IOException exception) {
            throw new IllegalArgumentException(
                    "No se pudo convertir la solicitud a JSON", exception);
        }
    }

    private JsonNode send(HttpRequest request, String url) {

        HttpResponse<String> response;

        try {
            response = httpClient.send(
                    request, HttpResponse.BodyHandlers.ofString());
        } catch (InterruptedException exception) {
            Thread.currentThread().interrupt();
            throw new ApiException(0, "Operación interrumpida");
        } catch (IOException exception) {
            throw new ApiException(0,
                    "No se pudo conectar con el servicio: " + url);
        }

        String body = response.body() == null ? "" : response.body().trim();

        if (response.statusCode() / 100 != 2) {
            throw new ApiException(
                    response.statusCode(),
                    body.isEmpty() ? "Error HTTP " + response.statusCode() : body);
        }

        if (body.isEmpty()) {
            return MissingNode.getInstance();
        }

        try {
            return mapper.readTree(body);
        } catch (IOException exception) {
            throw new ApiException(response.statusCode(),
                    "Respuesta no válida del servicio: " + url);
        }
    }
}
