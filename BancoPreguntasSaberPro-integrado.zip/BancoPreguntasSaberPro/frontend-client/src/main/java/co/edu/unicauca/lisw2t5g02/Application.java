package co.edu.unicauca.lisw2t5g02;

import java.awt.EventQueue;

import javax.swing.UIManager;

import co.edu.unicauca.lisw2t5g02.client.ApiClients;
import co.edu.unicauca.lisw2t5g02.config.ServiceUrls;
import co.edu.unicauca.lisw2t5g02.presentation.LoginView;
import co.edu.unicauca.lisw2t5g02.presentation.MainMenuView;

/**
 * Entry point of the Swing client.
 *
 * The client has no database and no business rules: every screen talks to
 * the four microservices (Identity, Question, Review, Notification) through
 * their REST API. Base URLs can be overridden with system properties such as
 * -Dquestion.url=http://host:8080 or environment variables QUESTION_URL.
 */
public final class Application {

    private Application() {
    }

    public static void main(String[] args) {

        applyNimbus();

        ApiClients api = ApiClients.create(ServiceUrls.fromEnvironment());

        EventQueue.invokeLater(() -> showLogin(api));
    }

    private static void showLogin(ApiClients api) {
        new LoginView(api.identity(), user ->
                new MainMenuView(user, api, () -> showLogin(api))
                        .setVisible(true)
        ).setVisible(true);
    }

    private static void applyNimbus() {
        try {
            for (UIManager.LookAndFeelInfo info
                    : UIManager.getInstalledLookAndFeels()) {
                if ("Nimbus".equals(info.getName())) {
                    UIManager.setLookAndFeel(info.getClassName());
                    break;
                }
            }
        } catch (Exception ignored) {
            // The default look and feel is used.
        }
    }
}
