Este cliente Swing se integra en el proyecto raíz como módulo Maven `frontend-client`.
Consulta el `README.md` de la raíz para compilar y ejecutar el sistema completo. La documentación original del cliente se conserva en `README.md`.
