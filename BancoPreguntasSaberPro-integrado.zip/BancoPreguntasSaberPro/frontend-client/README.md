# Banco de Preguntas Saber Pro — Cliente Swing

Interfaz de escritorio (Java Swing) separada del backend. **No tiene base de datos
ni reglas de negocio**: cada pantalla consume por HTTP + JSON los cuatro
microservicios (`questionbank`).

## Arquitectura

```text
presentation/  Vistas Swing (LoginView, MainMenuView, CreateQuestionView, GUIQuestions,
               AdminReviewView, ReviewerView, NotificationsView) + QuestionForm reutilizable
client/        Clientes REST: IdentityClient, QuestionClient, ReviewClient,
               NotificationClient (sobre RestClient con java.net.http + Jackson)
model/         Question, User, ReviewAssignment, Notification, enums de estado y rol
config/        ServiceUrls (URL base de cada microservicio)
```

Las llamadas HTTP se ejecutan fuera del hilo de Swing (`Background`, basado en
`SwingWorker`), así la interfaz no se congela.

## Pantalla → microservicio

| Pantalla | Rol | Servicio y endpoint |
|---|---|---|
| Inicio de sesión | todos | Identity `POST /api/auth/login` |
| Crear pregunta (HU-1.1) | Autor | Question `POST /api/questions` |
| Mis preguntas (HU-1.2/1.3) | Autor | Question `GET /api/questions`, `PUT`, `POST …/submit-for-review`, `POST …/return-to-draft` |
| Ver completa + observaciones | Autor | Question `GET /{id}` + Review `GET /api/reviews/{questionId}` |
| Asignar revisores (HU-2.1) | Admin | Review `GET /pending`, `POST /assign` · Identity `GET /api/users?role=REVIEWER` · Question `GET /{id}` |
| Mis preguntas asignadas (HU-2.2) | Revisor | Review `GET /reviewer/{id}`, `POST /{questionId}/decision` · Question `GET /{id}` |
| Mis notificaciones | todos | Notification `GET /api/notifications`, `PATCH /{id}/read` |

## Usuarios de prueba (los crea Identity al iniciar)

| Rol | Correo | Clave |
|---|---|---|
| Administrador | admin@unicauca.edu.co | admin123 |
| Autor | autor1@unicauca.edu.co / autor2@unicauca.edu.co | autor123 |
| Revisor | revisor1@ / revisor2@ / revisor3@unicauca.edu.co | revisor123 |

## Cómo ejecutar

1. Iniciar RabbitMQ (`localhost:5672`, guest/guest).
2. Iniciar los cuatro microservicios (Identity 8081, Question 8080, Review 8082, Notification 8083).
3. Ejecutar este cliente:

```bash
mvn test
mvn compile exec:java
```

Si los servicios están en otra máquina o puerto:

```bash
mvn compile exec:java -Dquestion.url=http://host:8080 -Didentity.url=http://host:8081 \
                      -Dreview.url=http://host:8082 -Dnotification.url=http://host:8083
```

(también sirven las variables de entorno `QUESTION_URL`, `IDENTITY_URL`, `REVIEW_URL`, `NOTIFICATION_URL`).

## Cambios frente al primer corte

Se retiraron del cliente el dominio local, SQLite, Argon2, SMTP y el Observer de
estadísticas: esas responsabilidades ahora viven en los microservicios.
En el formulario, el campo «Nombre» se reemplazó por «Categoría», que es el dato que
exige Question Service. La administración de usuarios no hace parte de las historias
del segundo corte; los usuarios los crea Identity.

## Pruebas

`mvn test` ejecuta JUnit 5 sobre la capa `client`, `config` y `model` usando un
servidor HTTP simulado (sin necesidad de levantar el backend).
