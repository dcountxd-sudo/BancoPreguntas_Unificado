# Banco de Preguntas Saber PRO

Proyecto integrado del segundo corte de Ingeniería de Software II. Contiene cuatro microservicios Spring Boot y un cliente de escritorio Java Swing.

## Estructura

- `question-service/`: creación, validación, consulta y estados de preguntas (puerto 8080).
- `identity-service/`: usuarios, roles y autenticación (puerto 8081).
- `review-service/`: asignación de revisores y evaluaciones (puerto 8082).
- `notification-service/`: notificaciones por correo y dentro de la aplicación (puerto 8083).
- `frontend-client/`: interfaz Swing que consume los servicios mediante REST.
- `docker-compose.yml`: RabbitMQ para comunicación por eventos.

Cada microservicio mantiene su propia base H2 en memoria. Los datos se reinician cuando se detiene el servicio.

## Requisitos

- JDK 17 o superior (el proyecto compila con Java 17).
- Maven 3.9 o superior.
- Docker Desktop (para RabbitMQ), o una instalación local de RabbitMQ.

## Compilar y ejecutar pruebas

Desde esta carpeta:

```bash
mvn clean verify
```

Este comando compila todos los módulos y ejecuta las pruebas disponibles, incluido el cliente Swing.

## Iniciar el sistema

1. Iniciar RabbitMQ:

```bash
docker compose up -d
```

2. En una terminal distinta para cada comando, desde la raíz del proyecto, iniciar los cuatro servicios:

```bash
mvn -pl identity-service spring-boot:run
mvn -pl question-service spring-boot:run
mvn -pl review-service spring-boot:run
mvn -pl notification-service spring-boot:run
```

3. En otra terminal, iniciar la interfaz:

```bash
mvn -pl frontend-client exec:java
```

La interfaz se conecta por defecto a `localhost`: Identity 8081, Question 8080, Review 8082 y Notification 8083.

## Swagger / OpenAPI

- Question: http://localhost:8080/swagger-ui.html
- Identity: http://localhost:8081/swagger-ui.html
- Review: http://localhost:8082/swagger-ui.html
- Notification: http://localhost:8083/swagger-ui.html

Los documentos OpenAPI están en `/v3/api-docs` en cada servicio.

## Usuarios de prueba

Identity crea usuarios de prueba al iniciar:

| Rol | Correo | Clave |
|---|---|---|
| Administrador | admin@unicauca.edu.co | admin123 |
| Autor | autor1@unicauca.edu.co / autor2@unicauca.edu.co | autor123 |
| Revisor | revisor1@unicauca.edu.co / revisor2@unicauca.edu.co / revisor3@unicauca.edu.co | revisor123 |

## Prueba manual del flujo principal

1. Iniciar sesión como autor.
2. Crear una pregunta de selección múltiple y comprobar que queda en Borrador.
3. Enviar la pregunta a revisión.
4. Iniciar sesión como administrador y asignar entre uno y tres revisores.
5. Iniciar sesión con cada revisor asignado y registrar su decisión. Para rechazar, escribir una observación.
6. Comprobar que el estado final se actualiza cuando todos los revisores asignados han evaluado.
7. Consultar las notificaciones del autor y del administrador.

## Notas

- RabbitMQ debe estar disponible en `localhost:5672` con usuario y contraseña `guest`.
- La consola de administración de RabbitMQ queda en http://localhost:15672 (guest/guest).
- Los servicios usan H2 en memoria; no son bases persistentes.
- El escenario de escalabilidad del informe es un objetivo de calidad pendiente de validar mediante pruebas de carga; no debe presentarse como una medición ya realizada.
- El frontend es una aplicación Swing independiente a nivel de código, pero se incluye como módulo del mismo proyecto Maven para facilitar la compilación conjunta.
